utils::globalVariables(c(
  # dplyr / data manipulation variables
  "stratumId", "treatment", "n", "rowId", "weight",
  "is_nco", "est", "outcome_id", "y", "SY", "S2",
  # additional identifiers and helper variables
  "..keep"
))