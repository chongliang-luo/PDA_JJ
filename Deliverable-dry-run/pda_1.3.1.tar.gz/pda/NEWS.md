

---
## version 1.3.0 
- Add pdaCataog() and DisC2o, ODACH_CC, COLA, ODACT, LATTE models

---
## version 1.2.8 
- Update package maintainer information.

---
## version 1.2.7
- Fix the alias bug in ODACATH model.

---
## version 1.2.6 
- Fix the bugs in ODACAT model.
- Add new model ODACATH.

---
## version 1.2.5 
- The package has not been uploaded to CRAN since 1.0.3.
- Fix and modify the PDA GitHub version to meet the CRAN policy.





 

