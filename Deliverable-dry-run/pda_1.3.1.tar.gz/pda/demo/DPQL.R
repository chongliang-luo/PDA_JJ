require(lme4)
require(minqa)
require(data.table)
require(pda) 

## The demo example for DPQL will be added to https://github.com/Penncil/pda

## We run the example in local directory. 
## In actual collaboration, the data communication can be done via the PDA_OTA platform https://pda-ota.pdamethods.org/
## Each site can access via web browser to transfer aggregate data and check the progress of the project.
